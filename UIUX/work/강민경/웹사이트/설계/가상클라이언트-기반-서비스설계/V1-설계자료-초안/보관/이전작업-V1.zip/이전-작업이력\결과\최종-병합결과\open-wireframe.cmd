@echo off
setlocal
set "BASE=%~dp0"
set "TARGET=%BASE%09-최종-와이어프레임-세트.html"
set "CHROME=C:\Program Files\Google\Chrome\Application\chrome.exe"
set "EDGE=C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"

if not exist "%TARGET%" (
  echo [ERROR] File not found:
  echo %TARGET%
  pause
  exit /b 1
)

if exist "%CHROME%" (
  start "" "%CHROME%" "%TARGET%"
  exit /b 0
)

if exist "%EDGE%" (
  start "" "%EDGE%" "%TARGET%"
  exit /b 0
)

echo [ERROR] Chrome or Edge was not found.
pause
exit /b 1
