# Flow 충돌 후 수정 화면 계약 SCR-R01~07

상태: `REVISED_SCREEN_CANDIDATE_POOL`

## SCR-R01 Resume 진입·객체 구분

- 관련: PAGE-001·021, FL-R01·R07
- Section: Resume summary, Restore preview, Apply confirmation.
- Content: 저장 예시 시점·필터 요약·후보 수·확인 상태.
- UI: `예시 보기 → Draft로 가져오기 → 조건 적용` 3단계.
- State: ResumeAvailable, RestorePreview, DraftReady, Applying, Results, Error.
- Validation: Saved·Draft·Applied를 같은 badge·문구로 표시하지 않음.
- Focus: Resume 제목 → Draft 버튼 → 적용 후 Results 제목 → 취소 후 호출 버튼.
- 금지: 예시 보기 클릭 즉시 결과 변경.

## SCR-R02 보관 가이드 이중 종료

- 관련: PAGE-016·021, FL-R02
- Section: 보관 목표, 방식 차이, 실제 지원 상태, 다음 행동.
- UI: `가이드만 마치기`와 `관련 방식 보기`를 동등한 종료로 제공.
- State: GuideDefault, MethodExpanded, SupportPartial, Complete, ReturnContext.
- Validation: 검색·OCR·영구 보존 CTA 없음.
- 복귀: PAGE-021에서 GUIDE-CONTEXT로 원문 제목·스크롤 위치 복원.

## SCR-R03 EVIDENCE-STATUS 공통 렌더링

- 관련: PAGE-021·상세·020, FL-R03
- 필드: subjectId, status, source, checkedAt, changeRisk, note.
- 상태 문구: 확인·일부 확인·재확인 필요·미확인·HOLD.
- UI: 카드 요약 badge+text, 상세 Section, 브랜드 장부 행.
- Error: DISPLAY_ERROR를 별도 표시하고 원본 status를 임의 변경하지 않음.
- Offline: checkedAt 유지, `현재 재확인 불가` 추가.
- 접근성: 색 외 상태 이름·확인일 텍스트 필수.

## SCR-R04 PAGE-002·003 책임 분리

- PAGE-002: 생활 조건·기록량·매체 선호 입력, 건너뛰기, Draft 유지.
- PAGE-003: 기본안·선택 옵션 미리보기, 적용·수정·보류.
- Validation: PAGE-002에서 결과를 확정하지 않고 PAGE-003에서 입력을 새로 요구하지 않음.
- Error: 결과 계산 실패 시 입력과 기본안 유지.
- Focus: PAGE-003 Error→다시 시도, 뒤로→PAGE-002 첫 변경 필드.

## SCR-R05 PAGE-019 정책 도움 제한

- 관련: 전 호출 Page, FL-R05
- PAGE-019 Content: 저장·권한·삭제·내보내기·연동·복원 정책과 영향.
- 호출 Page Content: 작업 입력·현재 상태·재시도·취소.
- UI: 관련 정책 앵커와 `작업으로 돌아가기`.
- Validation: PAGE-019에서 FILTER·COMPARE·기록 입력을 직접 변경하지 않음.
- RETURN-CONTEXT: sourcePage, sourceState, anchor, focusTarget.

## SCR-R06 접근성 사실·판단 분리

- 관련: PAGE-021·상세, FL-R06
- 상품 사실: 치수·무게·글자 크기·조작 방식·필요 도구·근거 상태.
- 판단 가이드: 받는 사람에게 확인할 질문·모름·보류 이유.
- UI: Facts table과 Question guide를 별도 heading·Section으로 분리.
- Validation: 사람 특성을 점수로 변환하지 않음.
- Empty: 접근성 사실 없음→미확인, 일반 추천 점수로 대체 금지.

## SCR-R07 Filter 3객체 상태 표시

- 관련: PAGE-021, FL-R07
- SAVED-SAMPLE: 읽기 전용 예시 카드.
- CURRENT-DRAFT: 편집 중 fieldset, 결과 수 예고.
- APPLIED-FILTER: Results 상단 요약, 현재 결과의 근거.
- 적용: Draft→Applied 교체 후 Results 갱신.
- 취소: Draft를 Applied 복사본으로 되돌리고 Results 유지.
- Error·Offline: 세 객체와 기존 Results 유지.
- 접근성: 각 영역에 heading/legend, 상태 변화 aria-live.

## 전달

- 수정 화면 계약: 7개
- 기존 화면설계 9안과 상태 15종은 삭제하지 않음.
- 다음 구현: PAGE-001·021·020 조작형 후보에 SCR-R01·03·05·07 우선 반영.
