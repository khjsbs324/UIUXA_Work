(() => {
  const page = document.title.includes('카테고리') ? 'category' : document.title.includes('브랜드') ? 'brand' : 'main';
  const stateData = {
    main: {
      Default: ['기본 화면', '상황·방식·원칙을 탐색합니다.', '현재 메인'],
      Empty: ['이어볼 예시가 없습니다', '새 탐색은 그대로 시작할 수 있습니다.', '현재 메인·브랜드 원칙'],
      Error: ['일부 진입 카드를 불러오지 못했습니다', '전체 둘러보기는 계속 사용할 수 있습니다.', '내비게이션·선택 전 상태'],
      Offline: ['현재 연결을 확인할 수 없습니다', '기존 설명을 유지하고 최신 정보는 갱신하지 않습니다.', '현재 메인·기존 설명'],
      Resume: ['이 기기에 남은 예시', '범위를 확인해도 현재 결과는 바뀌지 않습니다.', 'SAVED-SAMPLE·현재 결과'],
      HOLD: ['아직 확정하지 않은 기능입니다', '공동 기록·동기화·구매는 실행하지 않습니다.', '현재 선택·대안 경로']
    },
    category: {
      Default: ['기본 결과', '현재 적용 조건으로 후보를 표시합니다.', 'Draft·Applied·Compare'],
      Empty: ['조건에 맞는 후보가 없습니다', '조건을 수정하거나 확인 후 전체 보기로 이동합니다.', 'Draft·Applied·Compare'],
      Error: ['새 결과를 계산하지 못했습니다', '이전 결과를 유지합니다.', 'Draft·Applied·이전 Results·Compare'],
      Offline: ['근거를 재확인할 수 없습니다', '기존 확인일을 유지합니다.', 'Evidence·Filter·Compare'],
      Resume: ['저장 예시를 입력으로 가져옵니다', '적용 전까지 결과는 바뀌지 않습니다.', 'Saved·Applied·Results'],
      HOLD: ['정책 확인 전에는 실행할 수 없습니다', '구성 비교와 후보 보류만 제공합니다.', 'Filter·Compare·Evidence']
    },
    brand: {
      Default: ['기본 브랜드 화면', '문제·원칙·적용·근거를 연결합니다.', '브랜드 정의·원칙'],
      Empty: ['공식 연혁·성과 자료가 없습니다', '확인된 경험 원칙은 유지합니다.', '브랜드 정의·원칙'],
      Error: ['근거 상세를 불러오지 못했습니다', '장부의 원본 상태는 바꾸지 않습니다.', 'Evidence 원본'],
      Offline: ['최신 상태를 재확인할 수 없습니다', '기존 확인일을 유지합니다.', 'checkedAt·source'],
      Resume: ['보던 원칙으로 돌아갑니다', '개인 기록이 아닌 적용 사례 위치를 복원합니다.', 'RETURN-CONTEXT'],
      HOLD: ['이름과 최종 슬로건은 미확정입니다', 'DAMORI는 가칭이며 상표·성과를 확정하지 않습니다.', '철학·경험 원칙']
    }
  };
  const actions = {
    Default: ['주요 콘텐츠 보기', '상태 도움'], Empty: ['새 탐색 시작', '전체 보기'],
    Error: ['이전 내용 보기', '다시 확인'], Offline: ['기존 정보 보기', '상태 도움'],
    Resume: page === 'brand' ? ['이어서 보기', '처음부터 보기'] : ['범위 검토', '취소'],
    HOLD: ['확정 범위 보기', '상태 설명']
  };
  if (!document.querySelector('.skip')) {
    const skip = document.createElement('a'); skip.className = 'skip'; skip.href = '#main'; skip.textContent = '본문 바로가기';
    document.body.prepend(skip); const main = document.querySelector('main'); if (main && !main.id) main.id = 'main';
    const style = document.createElement('style'); style.textContent = '.skip{position:absolute;top:-5rem;left:1rem;background:#111;color:#fff;padding:.75rem;z-index:20}.skip:focus{top:1rem}'; document.head.append(style);
  }
  document.querySelectorAll('button:not([type])').forEach(button => button.type = 'button');
  const main = document.querySelector('main');
  const resumeNode = page === 'main' ? document.querySelector('#resume') : null;
  const resumePlaceholder = page === 'main' ? document.createComment('Resume slot: no SAVED-SAMPLE') : null;
  const controls = document.createElement('section'); controls.setAttribute('aria-label', '상태 검증'); controls.className = 'status';
  controls.innerHTML = `<strong>최종 상태 검증</strong><div class="actions">${Object.keys(stateData[page]).map(key => `<button type="button" class="secondary" data-final-state="${key}">${key}</button>`).join('')}</div><div id="final-state-slot"></div>`;
  main?.prepend(controls);
  const live = document.querySelector('#live');
  if (page === 'category' && live) live.textContent = 'UI 구조 검증용 가상 샘플 4개입니다. 실제 상품·가격·지원 정보가 아닙니다.';
  if (page === 'main') {
    const methodCopies = document.querySelectorAll('.method p');
    if (methodCopies[0]) methodCopies[0].textContent = '촉각과 물성을 활용하는 방식 가설입니다. 치수·재료·리필은 실제 출처 확인이 필요합니다.';
    if (methodCopies[1]) methodCopies[1].textContent = '빠른 입력과 탐색 가능성을 검토하는 방식 가설입니다. 검색·내보내기·동기화 지원은 미확정입니다.';
    if (methodCopies[2]) methodCopies[2].textContent = '두 매체의 역할과 수동 단계를 검토하며 자동 연결이나 효과를 전제하지 않습니다.';
  }
  if (page === 'brand' && live) live.textContent = 'VC-08·11·14·24·27과 SR-019에 연결된 브랜드 설계 가설입니다. 이름·효과·상품·성과는 미확정입니다.';
  function showState(key) {
    const data = stateData[page][key], pair = actions[key], slot = document.querySelector('#final-state-slot');
    slot.innerHTML = key === 'Default' ? '' : `<section class="status" tabindex="-1"><h2>${data[0]}</h2><p>${data[1]}</p><p><strong>보존:</strong> ${data[2]}</p><div class="actions"><button type="button">${pair[0]}</button><button type="button" class="secondary">${pair[1]}</button></div></section>`;
    if (page === 'main' && resumeNode) {
      if (key === 'Empty' && resumeNode.isConnected) resumeNode.replaceWith(resumePlaceholder);
      if (key !== 'Empty' && !resumeNode.isConnected) resumePlaceholder.replaceWith(resumeNode);
    }
    if (live) { live.setAttribute('role', key === 'Error' ? 'alert' : 'status'); live.setAttribute('aria-live', key === 'Error' ? 'assertive' : 'polite'); live.textContent = `${data[0]}. ${data[1]}`; }
    slot.querySelector('section')?.focus();
  }
  controls.addEventListener('click', event => { const button = event.target.closest('[data-final-state]'); if (button) showState(button.dataset.finalState); });
  if (page === 'category' && typeof items !== 'undefined') {
    const sources = {a1:['UI-IMPL-PAGE021','최종 PAGE-021 정적 구현'],d1:['UI-IMPL-PAGE021','최종 PAGE-021 정적 구현'],a2:['POLICY-HOLD','정책 자료 없음'],d2:['FEATURE-HOLD','공유 지원 자료 없음']};
    items.forEach(item => { const old = item.e, source = sources[item.id]; item.e = {subjectId:source[0],status:old.status,source:source[1],checkedAt:old.checkedAt,changeRisk:['HOLD','UNVERIFIED'].includes(old.status)?'HIGH':'MEDIUM',note:old.note}; });
    const originalRender = render; render = function(){ originalRender(); document.querySelectorAll('#results .card').forEach((card,index)=>{const item=visible[index];if(!item)return;const p=card.querySelector('p');p.textContent=`${item.e.source} · 위험 ${item.e.changeRisk} · ${item.e.note}`;}); }; render();
  }
  if (page === 'brand' && typeof evidence !== 'undefined') {
    evidence.forEach((item,index) => { item.subjectId = ['UX-CHOICE','PRODUCT-MATERIAL','FEATURE-SYNC','CLAIM-ENV'][index]; item.changeRisk = item.risk; item.source = index === 0 ? '최종 PAGE-001·021 구현 + SCR-R01·R07' : item.source; });
    renderLedger = function(){ document.querySelector('#ledger').innerHTML=evidence.map(item=>`<div class="ledger-row"><strong>${item.label}</strong><span class="badge">${item.status} · ${item.checkedAt}</span><span>${item.subjectId} · ${item.source} · 위험 ${item.changeRisk}<br>${item.note}</span></div>`).join(''); }; renderLedger();
  }
})();
