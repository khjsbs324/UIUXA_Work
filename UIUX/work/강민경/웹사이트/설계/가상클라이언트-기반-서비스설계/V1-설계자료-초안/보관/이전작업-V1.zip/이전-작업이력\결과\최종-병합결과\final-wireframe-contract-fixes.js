(() => {
  copy.brand.Error[0] = '근거 상세를 불러오지 못했습니다';
  const stateActions = {
    main:{Empty:['새 탐색 시작','전체 보기'],Error:['전체 보기','다시 확인'],Offline:['기존 설명 보기','상태 도움'],Resume:['범위 보기','새로 시작'],HOLD:['확정 원칙 보기','상태 설명']},
    category:{Empty:['조건 수정','확인 후 전체 보기'],Error:['이전 결과 보기','다시 적용'],Offline:['기존 후보 보기','상태 도움'],Resume:['Draft로 가져오기','취소'],HOLD:['구성 비교','후보 보류']},
    brand:{Empty:['경험 원칙 보기','미확정 범위'],Error:['장부로 복귀','다시 확인'],Offline:['기존 장부 보기','연결 도움'],Resume:['이어서 보기','처음부터 보기'],HOLD:['확정 원칙 보기','명칭 상태']}
  };
  slot = function(){ if(state==='Default')return''; const data=copy[page][state],pair=stateActions[page][state]; return `<section class="state"><span class="tag">STATE · ${state}</span><h3>${data[0]}</h3><p class="preserve"><strong>보존</strong> ${data[1]}</p><div class="actions"><button type="button" class="primary">${pair[0]}</button><button type="button">${pair[1]}</button></div></section>`; };
  document.querySelectorAll('button:not([type])').forEach(button => button.type = 'button');
  const skip=document.createElement('a');skip.href='#view';skip.textContent='와이어프레임으로 이동';skip.style.cssText='position:absolute;left:1rem;top:-5rem;background:#111;color:#fff;padding:.7rem;z-index:9';skip.addEventListener('focus',()=>skip.style.top='1rem');skip.addEventListener('blur',()=>skip.style.top='-5rem');document.body.prepend(skip);
  render();
})();
