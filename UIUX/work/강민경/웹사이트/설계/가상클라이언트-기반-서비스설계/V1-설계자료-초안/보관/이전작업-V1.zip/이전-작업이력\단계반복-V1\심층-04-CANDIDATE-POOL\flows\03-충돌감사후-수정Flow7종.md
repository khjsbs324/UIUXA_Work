# 충돌 감사 후 수정 Flow 후보 FL-R01~07

상태: `REVISED_CANDIDATE_POOL`  
원본 FL-C01~12는 유지한다.

## FL-R01 메인 Resume 진입 계약

- 해결: CF-01
- 시작: PAGE-001 `이어보기`
- 단계: Resume link → PAGE-021 ResumeAvailable → 범위·시점 표시 → RestorePreview → 적용/취소 → Results.
- 데이터: `RESUME-SAMPLE`과 현재 Results를 분리.
- 실패: 예시 없음→MAIN-EMPTY, 읽기 실패→현재 메인 유지.
- Focus: PAGE-021 Resume 제목 → 적용 후 Results 제목 → 취소 후 호출 링크.
- 종료: 적용된 Results 또는 PAGE-001 복귀.

## FL-R02 보관 가이드 이중 종료

- 해결: CF-02
- 시작: PAGE-016 보관 원칙 가이드.
- 단계: 목표 선택 → Analog/Digital/Mixed 차이 → 지원 상태 → `이해 완료 / 관련 방식 보기`.
- 종료 A: 가이드 이해 완료, 상품 탐색 없음.
- 종료 B: GUIDE-CONTEXT를 포함해 PAGE-021 진입.
- 금지: 검색·OCR·영구 보존 기능 CTA.

## FL-R03 근거 상태 단일 원본

- 해결: CF-03
- 객체: `EVIDENCE-STATUS={subjectId,status,source,checkedAt,changeRisk,note}`.
- 단계: 카드 요약 → 근거 상세 → 호출 Page 복귀.
- 상태: `VERIFIED / PARTIAL / STALE / UNVERIFIED / HOLD`.
- Offline: checkedAt을 갱신하지 않고 `현재 재확인 불가`만 추가.
- 오류: 원본 읽기 실패 시 VERIFIED를 UNVERIFIED로 낮추지 않고 `DISPLAY_ERROR`를 별도 표시.
- 종료: 동일 객체를 PAGE-021·상세·PAGE-020에서 같은 문구로 렌더링.

## FL-R04 방식 찾기 Page 책임 분리

- 해결: CF-04
- PAGE-002: 생활 조건·기록량·매체 선호 입력과 건너뛰기.
- PAGE-003: 기본 구성·선택 옵션 미리보기, 적용·수정·보류.
- 오류: PAGE-003 계산 실패 시 PAGE-002 입력과 마지막 기본안 유지.
- 뒤로: PAGE-003→PAGE-002 입력 복원.
- 종료: 적용 후보 또는 조건 수정, 실제 저장·구매 없음.

## FL-R05 PAGE-019 역할 제한

- 해결: CF-05
- 호출 Page 소유: 현재 작업 상태·입력·오류·재시도.
- PAGE-019 소유: 저장·권한·삭제·내보내기·연동·복원 정책과 영향 설명.
- 단계: 호출 Page 상태 도움 → PAGE-019 관련 앵커 → 정책 확인 → RETURN-CONTEXT 복귀.
- 금지: PAGE-019에서 필터·비교·기록 입력을 직접 수정.
- 종료: 정책 이해 후 원 작업으로 복귀하거나 나가기.

## FL-R06 접근성 상품 정보 분리

- 해결: CF-06
- 사실 필드: 치수·무게·글자 크기·조작 방식·필요 도구·확인 상태.
- 판단 가이드: 선물 받는 사람에게 확인할 질문, 모름 허용, 보류 이유.
- 단계: Gift 조건 → 사실 필드 확인 → 미확인 구분 → 질문/후보 → 보류.
- 금지: 연령·장애·숙련도를 점수화하거나 `누구나 사용` 주장.
- 종료: 후보 선택이 아니라 안전한 확인 질문 확보도 성공으로 인정.

## FL-R07 조건 객체 3분리

- 해결: CF-07
- `SAVED-SAMPLE`: 이 기기에 남은 예시, 자동 적용 금지.
- `CURRENT-DRAFT`: 사용자가 현재 편집 중인 값.
- `APPLIED-FILTER`: 현재 Results를 만든 확정 조건.
- 단계: Saved preview → Draft로 복사 → 수정 → 적용 → Applied 교체.
- 취소: Draft 폐기, Applied와 Results 유지.
- 오류: Draft와 Applied 모두 유지, Results를 0개로 바꾸지 않음.
- 종료: 명시적 적용 또는 취소.

## 수정 Flow 전달

| Flow | 해결 이슈 | 영향 Page | 다음 검증 |
|---|---|---|---|
| FL-R01 | CF-01 | 001·021 | Resume 진입·focus |
| FL-R02 | CF-02 | 016·021 | 이중 종료 이해 |
| FL-R03 | CF-03 | 021·상세·020 | 상태 문구 동일성 |
| FL-R04 | CF-04 | 002·003 | 입력·미리보기 책임 |
| FL-R05 | CF-05 | 전 호출 Page·019 | Page 역할 과밀 해소 |
| FL-R06 | CF-06 | 021·상세 | 사실·판단 분리 |
| FL-R07 | CF-07 | 021 | Draft·Applied 보존 |

다음 단계: 수정 Flow 7개를 화면설계 후보 9안과 상태 스토리보드 15종에 대입해 stale 화면을 표시한다.
